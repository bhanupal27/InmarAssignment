﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVCAndOOP.Models
{

    public class OfferService
    {
        public OfferService() {   

        }
        
        public List<Product> GetAllProducts()
        {
            return getProducts();
        }
        private List<Product> Inventory { get; set; }

        private List<Product> getProducts()
        {
            List<Product> products = new List<Product> {
            new Product{ ProductName="P1",Price=1000,Description="P1 desc"},
            new Product{ ProductName="P2",Price=200,Description="P2 desc"},
            new Product{ ProductName="P3",Price=400,Description="P3 desc"},
            new Product{ ProductName="P4",Price=700,Description="P4 desc"},
            new Product{ ProductName="P5",Price=600,Description="P5 desc"},
            new Product{ ProductName="P6",Price=800,Description="P6 desc"}
            };
            return products;
        }
    }
}