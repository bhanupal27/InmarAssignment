﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVCAndOOP.Models
{
    public class Offer
    {
        public string OfferName { get; set; }
        public Product Products { get; set; }
    }
}