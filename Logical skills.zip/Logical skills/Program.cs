﻿using System;

namespace Logical_skills
{
    class Program
    {
        static void Main(string[] args)
        {
            //Write a program that loops through [1..100]. It should do the following:

            for (int i = 1; i <= 100; i++)
            {
                if (i % 3 == 0 && i % 5 == 0)
                {
                    Console.WriteLine("fizzbuzz");
                }
                if (i % 3 == 0 )
                {
                    Console.WriteLine("fizz");
                }
                if (i % 5 == 0)
                {
                    Console.WriteLine("buzz");
                }
            }



            //2) Write a program to reverse a string “abcdef” --> “fedcba” 
            string Name = "abcdef";
            var reverseName = Name.ToCharArray();
            for (int i = reverseName.Length-1; i >= 0; i--)
            {
                Console.Write(reverseName[i]);
            }
            Console.ReadLine();
        }
    }
}
